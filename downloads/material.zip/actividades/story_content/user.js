function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6n4nszCs8nN":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

